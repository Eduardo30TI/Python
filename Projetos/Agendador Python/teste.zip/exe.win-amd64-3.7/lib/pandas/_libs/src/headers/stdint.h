#ifndef _PANDAS_STDINT_H_
#define _PANDAS_STDINT_H_

#if defined(_MSC_VER) && (_MSC_VER < 1900)
#include "ms_stdint.h"
#else
#include <stdint.h>
#endif

#endif
